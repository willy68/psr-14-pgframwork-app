<?php

namespace App\Api\Client\Civilite;

use App\Models\Civilite;
use App\Api\AbstractApiController;

class CiviliteController extends AbstractApiController
{

    /**
     * Model class
     *
     * @var string
     */
    protected $model = Civilite::class;
}
