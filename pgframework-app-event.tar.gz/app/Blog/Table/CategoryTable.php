<?php

namespace App\Blog\Table;

use Framework\Database\Table;

/**
 *
 */
class CategoryTable extends Table
{

    /**
     * Undocumented variable
     *
     * @var string
     */
    protected $table = 'categories';
}
