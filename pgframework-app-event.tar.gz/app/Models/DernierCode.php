<?php

namespace App\Models;

use ActiveRecord;

class DernierCode extends ActiveRecord\Model
{
    public static $table_name = 'dernier_code';
}
