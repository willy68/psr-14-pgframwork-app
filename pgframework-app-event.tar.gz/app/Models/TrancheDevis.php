<?php

namespace App\Models;

use ActiveRecord;

class TrancheDevis extends ActiveRecord\Model
{
    public static $table_name = 'tranche_devis';
}
