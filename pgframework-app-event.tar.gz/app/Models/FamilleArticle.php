<?php

namespace App\Models;

use ActiveRecord;

class FamilleArticle extends ActiveRecord\Model
{
    public static $table_name = 'famille_article';
}
