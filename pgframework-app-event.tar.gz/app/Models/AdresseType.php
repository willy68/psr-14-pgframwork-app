<?php

namespace App\Models;

use ActiveRecord;

class AdresseType extends ActiveRecord\Model
{
    public static $table_name = 'adresse_type';
}
