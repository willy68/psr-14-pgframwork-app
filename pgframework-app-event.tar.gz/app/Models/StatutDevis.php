<?php

namespace App\Models;

use ActiveRecord;

class StatutDevis extends ActiveRecord\Model
{
    public static $table_name = 'statut_devis';
}
