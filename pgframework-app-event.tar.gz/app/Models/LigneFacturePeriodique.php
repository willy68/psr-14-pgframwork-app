<?php

namespace App\Models;

use ActiveRecord;

class LigneFacturePeriodique extends ActiveRecord\Model
{
    public static $table_name = 'ligne_facture_periodique';
}
