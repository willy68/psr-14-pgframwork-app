<?php

namespace App\Models;

use ActiveRecord;

class FacturePeriodique extends ActiveRecord\Model
{
    public static $table_name = 'facture_periodique';
}
