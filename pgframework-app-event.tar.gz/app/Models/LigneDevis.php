<?php

namespace App\Models;

use ActiveRecord;

class LigneDevis extends ActiveRecord\Model
{
    public static $table_name = 'ligne_devis';
}
