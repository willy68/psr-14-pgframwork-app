<?php

namespace App\Models;

use ActiveRecord;

class Tva extends ActiveRecord\Model
{
    public static $table_name = 'tva';
}
