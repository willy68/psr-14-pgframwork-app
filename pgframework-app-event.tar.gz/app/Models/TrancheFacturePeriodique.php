<?php

namespace App\Models;

use ActiveRecord;

class TrancheFacturePeriodique extends ActiveRecord\Model
{
    public static $table_name = 'tranche_facture_periodique';
}
