<?php

namespace App\Models;

use ActiveRecord;

class Reglement extends ActiveRecord\Model
{
    public static $table_name = 'reglement';
}
