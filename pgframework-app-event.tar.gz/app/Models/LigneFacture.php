<?php

namespace App\Models;

use ActiveRecord;

class LigneFacture extends ActiveRecord\Model
{
    public static $table_name = 'ligne_facture';
}
