<?php

namespace App\Models;

use ActiveRecord;

class TrancheFacture extends ActiveRecord\Model
{
    public static $table_name = 'tranche_facture';
}
