<?php

namespace App\Models;

use ActiveRecord;

class Role extends ActiveRecord\Model
{
    public static $table_name = 'role';
}
