<?php

namespace Framework;

class Module
{
    public const DEFINITIONS = null;

    public const MIGRATIONS = null;

    public const SEEDS = null;

    public const ANNOTATIONS = [];
}
