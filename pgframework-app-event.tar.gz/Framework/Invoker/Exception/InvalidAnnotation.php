<?php

namespace Framework\Invoker\Exception;

use Exception;

class InvalidAnnotation extends Exception
{
}
