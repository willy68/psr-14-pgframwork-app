<?php

namespace Framework\Auth;

class ForbiddenException extends \Exception
{
}
