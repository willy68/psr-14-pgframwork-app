<?php

namespace Framework\Router\Annotation\Exception;

class RouteAnnotationException extends \Exception
{
}
