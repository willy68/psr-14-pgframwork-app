<?php

namespace Framework\Database;

class NoRecordException extends \Exception
{
  
}
